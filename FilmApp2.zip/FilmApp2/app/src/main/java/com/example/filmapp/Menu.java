package com.example.filmapp;

public class Menu {
    private String nama;
    private String deskripsi;
    private String gambar;

    public Menu(String datanama, String datadeskripsi, String datagambar){
        nama = datanama;
        deskripsi = datadeskripsi;
        gambar = datagambar;
    }

    public String getNama() {
        return nama;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public String getGambar() {
        return gambar;
    }
}
