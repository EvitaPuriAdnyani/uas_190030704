package com.example.filmapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {
    TextView tvjudul;
    TextView tvdesc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        tvjudul = findViewById(R.id.tvNama);
        tvjudul.setText(getIntent().getStringExtra("judul"));
        tvdesc = findViewById(R.id.tvDesc);
        tvdesc.setText(getIntent().getStringExtra("description"));
    }
}